counter = 0
while counter < 100:
  print counter
  counter +=2
   
