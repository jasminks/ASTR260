import math
from math import e

print e**(-x)
