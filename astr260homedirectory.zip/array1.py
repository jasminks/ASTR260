from numpy import zeros
a=zeros(4,float)
print(a)
