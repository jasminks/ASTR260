from math import exp
import math 


a=1.
b=2.
x=1.
y=1.


for k in range (10):
  if x > 0:
   x=y*(a+x**2)
  else:
  x=
  
def g(x,y):
  return  b/(x**2+a)

for k in range (100):
  x=f(x,y)
  y=g(x,y)
 
print x,y
