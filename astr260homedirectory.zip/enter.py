x = int (input("Enter a whole number that is not greater than 10: "))
while(x > 10):
	print("NOOOOOOO")
	x = int(input("PLEASE enter a whole number NOT greater than 10:"))
print("Your lucky number is" ,x)
