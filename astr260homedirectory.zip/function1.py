import math

x=0
def f(x):
    return (x**3)/((math.exp(x)-1)

z = f(x)

p=x[:,0]
plot (p)

print f(1)
