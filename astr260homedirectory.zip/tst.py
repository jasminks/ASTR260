x=-7
while(x<0):
	print("a")


