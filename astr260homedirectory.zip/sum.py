import math

s=0
f(x)=
for k in range(1,101):
  s+=1./k+

print(s)
