from numpy import array
from numpy.linalg import eighvalsh

A=array[[1,2],[2,1],float]

X=eigvalsh(A)

print x

#x is eigen values

