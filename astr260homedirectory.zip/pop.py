r=[3,6,9]

print r

r.pop(1)

print r 
