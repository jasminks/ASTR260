r=[3,6,9]
import math
l=math.sqrt(r[0]**2+r[1]**2+r[2]**2)
r.pop(2)

print"The length is ",l,"."
