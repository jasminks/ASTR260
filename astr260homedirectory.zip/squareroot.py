#Date: 8/29/14
#Author: Jasmin Silva

import math
x=float(input("Enter x:")
y=math.sqrt(x)
print "the square root of x=", x ,"is",y

