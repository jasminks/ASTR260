#Balldrop program

import math

h=float(input("Input height of the building:"))
t=math.sqrt(2*(h)/(9.8))

print"It will take ",t," seconds for the ball to hit the ground"
